/*
We did the assignment by link the leaflet to the RESTAPI of the nodejs via $http service.
we are storing/retrieving/update/delete our data to mongodb via the CRUD operations implemented on the server part of the assignment..
we are using $http service to connect leaflet contrller to model or back end in the MVC architecture.
*/
var app = angular.module("app", ["leaflet-directive"]);

app.controller("TheController", [
    "$scope",
    "$http",//$http service is a function that is used to generate an HTTP request and returns a promise.
    function($scope, $http) {
        angular.extend($scope, {
            castellon: {
                lat: 39.98685368305097,
                lng: -0.04566192626953125,
                zoom: 14
            },
            tiles: {
                url: "http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
                options: {
                    attribution: '© <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                }
            },

        })
        // an array to store retrieved data via get method from database via the server implemented methods
        $scope.data = new Array();
        $scope.counter = 0;// is a counter for the number of tasks
        // the $http.get is to retrieve the whole data implemented in the our RestAPI
        $scope.task;
        $http.get('http://localhost:3000/Geotodo').then(function(response) {

            $scope.data = response.data;// storing only the data part of the response

        });

        //to create the markers array
        $scope.markers = [];
        $scope.$on("leafletDirectiveMap.mousedown", function(event, args) {
            var mouseButton = args.leafletEvent.originalEvent.button;
            if (mouseButton == 2) { // Right button
                var latlng = args.leafletEvent.latlng;
                reverseGeocoding(latlng);
            }
        });

        function reverseGeocoding(latlng) {
            var urlString = "http://nominatim.openstreetmap.org/reverse?format=json&lat=" +
                latlng.lat + "&lon=" +
                latlng.lng + "&zoom=18&addressdetails=1";
            $http.get(urlString).then(addMarker);
        }

        function addMarker(response) {
        // store the location and intial message on mouse down in marker1 object
            var marker1 = {
                id: 20,
                message: "set task",
                Due: new Date(),
                lat: parseFloat(response.data.lat),
                lng: parseFloat(response.data.lon),
                postAddress: response.data.display_name,
                RemDays: 2
            }
            // after save marker1 using the   $http.post method
            $http.post('http://localhost:3000/Geotodo', marker1, {
                headers: {
                    'Content-Type': 'application/json; charset=UTF-8'// json type of content which match with body parser of our server side code
                }
            });

            $scope.markers.push(marker1);// push new information to the array and display on the viewer

        }
        $scope.currentMarker = {};
        // helps us to reload the page based on the events such as updating and deleting mean we need to store on database before update or deletion rather than array
        $scope.reloadRoute = function() {
            location.reload();
        }
        //show the detail of the task and the editable box for both message and date
        $scope.showInfo = function(index) {
            $scope.currentMarker = $scope.markers[index];


        }
        //update the existing message and date based on objectid obtained from datatbase via put method
        $scope.update = function() {// this method is calling on change(ng-change) of the input control of the dialog box.
          // the id 20 is constant for all records if it is 20 the value is on array not on database. so we need to refresh
          if($scope.currentMarker.id==20)//here we are refresh the page to replace on fly array value  by database value
          {
            $scope.reloadRoute();
        }
        // here the $scope.currentMarker.id must be objectid of the database not 20 defined at the template message or marker1 above
            $http.put('http://localhost:3000/Geotodo/' + $scope.currentMarker.id, $scope.currentMarker, {
                headers: {
                    'Content-Type': 'application/json; charset=UTF-8'
                }
            });
        }
        // shows the task title with its corresponding location for each marker definded by the loop and focus property
        $scope.show = function(index) {

            for (i = 0; i < $scope.markers.length; i++)
                $scope.markers[i].focus = false;
            $scope.markers[index].focus = true;
        }
      //the remove method remove records one by one from database and array
        $scope.remove = function(index, id) {
            if(id==20)//we can't delete with id equal to 20 because this id is not unique identifier
            {//However ,_id is unique identifier by refresh the page we will replace the id by _id
              $scope.reloadRoute();
          }
          //if the id different from 20 mean its value is equal to _id so delete using delete method implemented in CRUD RestAPI
          $http.delete('http://localhost:3000/Geotodo/' + id);
            $scope.markers.splice(index, 1);
        }
        $scope.search=function()// this function filter the list items on text change condition
        {
            $scope.markers=$scope.markers.filter(x => x.message.toLowerCase().startsWith($scope.task)==true);
            $scope.knowRemainingTime($scope.markers[0],0);
        }
        // the remdays array store the rmaining days and hours based on the difference.
        // if the difference is lessthan one day then calculate hours.
        $scope.Remdays=new Array();
        //the addCounter method helps us to copy the database values to array from data array defined in the above to markers array
        //this method is calling by the view
        $scope.addCounter = function(index, _id) {//_id is the unique identifier for each record in database,index is unique identifier for the list of tasks in the view
            var marker1 = {// this marker1 to store every attribute from the database separtely
                id: $scope.data[_id]._id,//here is the exchange of the ids from intial 20 to the objectid _id
                message: $scope.data[_id].message,
                Due: $scope.data[_id].Due,
                lat: parseFloat($scope.data[_id].lat),
                lng: parseFloat($scope.data[_id].long),
                postAddress: $scope.data[_id].postAddress,
                RemDays: $scope.data[_id].RemDays// unused attribute
            }

            if ($scope.counter <= index) {// the counter counts until the maximum index of the items or task listed in the view
               $scope.knowRemainingTime(marker1,$scope.counter);
                $scope.markers.push(marker1);// then push marker1 object with clear format
                $scope.counter = $scope.counter + 1;
            }


        }
        $scope.knowRemainingTime=function(marker1, counter)// calculates remaining days or hours by passing the filtered array elements and their index
        {
          console.log(marker1);
          var now=new Date();// store the current time from our computer
          var hour=0;// store the remaining hours
          var day=0;// store the ramainging days
          var plannedday=new Date(marker1.Due);
          day=plannedday.getDate()- now.getDate();//get the numbers of day
          $scope.Remdays[counter]=day +'d';//store in the remainingdays array
          if(day==0)
          {

            hour=plannedday.getHours()- now.getHours();// get the hours because day is 0
             $scope.Remdays[counter]=hour +'h';
          }
          if( day<0 || hour<0)
          {
             $scope.Remdays[counter]=0 +'h';
          }
        }
        $scope.currentMarker = {};
    }
]);
