var express = require('express');
var bodyParser = require("body-parser");
var app = express();
var port = 3000;
// our collection name is geotodo_tbls
// our database name is Geotodo
var Product = require("./model/product");
// import mongoose object for the purpose of casting given string to objectid
var ObjectId=require("./model/db");
// allow access control for the Crud opreations from browser
var allowCrossDomain = function(req, res, next) {
    res.header('Access-Control-Allow-Origin', "*");
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    next();
}
// a method which allows access to the crud opreations
    app.use(allowCrossDomain);
// json parser for all RESTAPI usage
app.use(bodyParser.json());
app.get("/Geotodo", function(req, res) {
    var stream = Product.find().stream();
    var results = {};
    stream.on('data', function(doc) {
            results[doc._id] = doc;
        }).on("error", function(err) {
            res.status(500);
            next(err);
        }).on('close', function() {
            res.status(200);
            res.json(results);
    });
});
app.get("/Geotodo/:id", function(req, res, next) {
    var idProduct = req.params.id;
 Product.findOne({id: idProduct}, function(err, product) {
       if(err) {
                   res.status(500);
                                next("Internal server error.");
         } else if(product == null) {
            res.status(404); // Not found
             next("No appointment with code " + idProduct + " found.");
        } else {
           res.status(200);
            res.json(product);
       }
    });
});



 app.post("/Geotodo", function(req, res, next) {
  // Add your code here.
   var product = req.body;
   var id = product.id;// we are not using this attribute instead objectId
   var message= product.message;
   var Due = product.Due;
   var lat = product.lat;
   var long = product.lng;
   var postAddress = product.postAddress;
   var RemDays = product.RemDays;// we are not use this attribute, because we are calculating remaining time on fly

 var product=new Product({

  "id": id,
  "message": message,
  "Due":  Due,
  "lat": lat,
  "long": long,
  "postAddress": postAddress,
  "RemDays": RemDays
 });

     product.save(function(err, product) {
        if(err) {
             res.status(500);
             next("Internal server error.");
         } else if(product == null) {
             res.status(404); // Not found
            next("No appointment with code " + idProduct + " found.");
         } else {
             res.status(201);
             res.json(product);
         }
      });


 });
 app.put("/Geotodo/:id", function(req, res, next) {
     // Add your code here.
     var product = req.body;
     var id =ObjectId.Types.ObjectId(product.id);// parse the string objectId to objectId
     var message= product.message;
     var Due = product.Due;
     var lat = product.lat;
     var long = product.lng;
     var postAddress = product.postAddress;
     var RemDays = product.RemDays;
     Product.update({"_id":id}, {$set:{"message": message, "Due": Due,"lat":lat,"long":long,"postAddress":postAddress,"RemDays":RemDays}},
        function(err, Product){
      res.json(product);
       res.end();
     });
 });
 app.delete("/Geotodo/:id", function(req, res, next) {
    var id = ObjectId.Types.ObjectId(req.params.id);
     Product.remove({_id: id}, function(err, result) {
         if(err) {
             res.status(500);
             next("Internal server error.");
        } else if(result.result.n == 0) {
             res.status(404); // Not found
             next("No appointment with code " + idProduct + " found.");
        } else {
            res.status(204);
             res.end();
      }

     });
 });

var server = app.listen(port, function () {
    console.log('Server running at http://127.0.0.1:' + port);

});
