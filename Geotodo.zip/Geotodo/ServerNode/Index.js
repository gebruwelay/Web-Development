const http = require('http'); // http module loaded

const hostname = '150.128.174.192';
const port = 3030;
const port2 = 4000;

// We create the server
const server = http.createServer((req, res) => {
  res.statusCode = 200; // Status code
  res.setHeader('Content-Type', 'text/plain'); // Response content type
  res.end('Gebru\n'); // Response body
});
// The server stasts listening
server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});
const server2 = http.createServer((req, res) => {
  res.statusCode = 200; // Status code
  res.setHeader('Content-Type', 'text/plain'); // Response content type
  res.end('Hello Server2\n'); // Response body
});
server2.listen(port2, hostname, () => {
  console.log(`Server running at http://${hostname}:${port2}/`);
});
