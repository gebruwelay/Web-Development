var mongoose = require("mongoose");
// Database connection to Geotodo
mongoose.connect("mongodb://localhost/Geotodo");
var db = mongoose.connection;
db.on("error", console.log.bind(console, "connection error."));
db.on("open", function () {
    console.log("Mongodb connected");
});

module.exports = mongoose;
