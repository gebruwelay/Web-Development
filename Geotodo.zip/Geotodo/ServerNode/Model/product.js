var db = require("./db");
// our collection with different data types of attributes
var Product = db.model('Geotodo_tbl', {
    id: {type: Number, require: true},
    message: {type: String, require: true},
    Due: {type: Date, require: true},
    lat: {type: Number, require: true},
    long: {type: Number, require: true},
    postAddress: {type: String, require: true},
    RemDays: {type: Number, require: true}
});

module.exports = Product;
